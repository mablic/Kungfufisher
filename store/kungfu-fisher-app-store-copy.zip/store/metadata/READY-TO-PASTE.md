# Kung Fu Fisher — Ready-to-paste App Store copy

English (U.S.). Updated for the 42-level build.

## App Name

Kung Fu Fisher

## Subtitle

Wuxia Skills. Arcade Fishing.

## Promotional Text

Trade your fishing rod for a blade. Explore 42 river challenges, discover seven martial arts manuals, and time each cast to turn a close miss into a great catch.

## Keywords

fishing,wuxia,arcade,sword,koi,river,aim,timing,casual,challenge,boat,reflex

## Description

A quiet river. A sharp blade. One perfectly timed cast.

Kung Fu Fisher brings martial arts to arcade fishing. Stand aboard a wooden skiff, aim beneath the surface, and cast your blade to catch the river's elusive fish. Simple controls make the first cast easy. Moving targets, changing weather, and limited-use techniques keep the next catch interesting.

HOLD. AIM. RELEASE.
Hold underwater to charge your cast, drag to adjust your aim, and release. Lead a fast-moving fish or hold a little longer to reach deeper water.

42 CHALLENGES, SEVEN RIVER REGIONS
Travel from Mistwood Creek through Reed Marsh, Rain River, Moonlit Lake, Storm Gorge, Jade Estuary, and Tempest Reach. Face sudden turns, small targets, armored fish, poor visibility, and waves that move your skiff.

SEVEN MARTIAL ARTS MANUALS
Strike a floating manual to equip a special technique. Cast twin blades, pierce a line of fish, sweep sideways, or send spinning swords through the water. Every manual grants three casts. Make each one count.

LEARN THE RIVER
Encounter 18 river creatures with different behaviors. Some dart away, some hide near the riverbed, and some need several strikes. Meet bull sharks, hammerheads, swordfish, and giant groupers in the new coastal chapters. Watch for glowing golden fish, and take care around protected turtles.

CHASE YOUR NEXT STAR
Earn up to three stars per level, complete seal challenges, and build catch combos to improve your score. Return to a familiar river with better timing and a new approach.

A WUXIA WORLD IN YOUR POCKET
Painted river scenery, misty mountains, lantern-lit water, and a wandering martial artist bring a little Jianghu atmosphere to every cast. Open the in-game field guide whenever you need a pause or a closer look at fish, techniques, and river challenges.

No account is required. Progress and preferences are saved on your device.

In-game text is currently in English.

## What’s New

- Added 12 levels, two coastal chapters, and four large species including sharks.
- Rebalanced all 42 levels, with a Trial every third stage.
- Improved frame-loop stability, background recovery, and multi-hit performance.
- Added a recovery prompt that restarts an interrupted run while keeping completed-level records.

- Added an About page with offline gameplay, optional ads, privacy information, and support contact.
- Completed the field guide descriptions for all seven regions.

- Added seven original wuxia-inspired background music themes, one for each region.
